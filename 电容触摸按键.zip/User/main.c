#include "stm32f10x.h"                  // Device header
#include "LED.h"
#include "UART.h"
#include "Delay.h"
#include "TIM_IO.h"
#include "OLED.h"

u16 n=0;

int main(void){
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);
	
	GPIO_InitTypeDef GPIO_InitStructure;
 	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_OD;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_7;
 	GPIO_Init(GPIOB, &GPIO_InitStructure);
	GPIO_WriteBit(GPIOB,GPIO_Pin_7,Bit_RESET);
	OLED_Init();
	UART_Init();
  TIM_Key_Init();
while(1){
	if(Touch_Scanf(0)==1){
		n++;
		OLED_ShowNum(3,3,n,3);  //按下之后该执行的代码
	}
 }
}

