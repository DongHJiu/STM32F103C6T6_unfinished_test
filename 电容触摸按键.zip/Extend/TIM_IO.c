#include "stm32f10x.h"                  // Device header
#include "Delay.h"
#include "OLED.h"

#define Touch_Val_MAX 0xffff
u16 touch_val = 0;

void TIM2_Init2(void){
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM2,ENABLE);
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA,ENABLE);
	
	GPIO_InitTypeDef GPIOLED_Init;
	GPIOLED_Init.GPIO_Mode=GPIO_Mode_IN_FLOATING;
	GPIOLED_Init.GPIO_Pin=GPIO_Pin_0;
	GPIOLED_Init.GPIO_Speed=GPIO_Speed_50MHz;
	GPIO_Init(GPIOA,&GPIOLED_Init);
	
	/**ARR和PSC设置的是定时时间
	*公式:定时频率=72MHZ/(PSC+1)/(ARR+1)
	*上公式中的72MHZ不知道是不是他所在的总线的频率（上网查下）
	*/
	      TIM_InternalClockConfig(TIM2);									          //使用内部时钟来驱动
	TIM_TimeBaseInitTypeDef InitPor_TIM;											 
	InitPor_TIM.TIM_ClockDivision=TIM_CKD_DIV1;								//设置时钟分割
	InitPor_TIM.TIM_CounterMode=TIM_CounterMode_Up;						//计数器向上计数模式
	InitPor_TIM.TIM_Period=10000-1;			                			//ARR自动重装器的值
	InitPor_TIM.TIM_Prescaler=7200-1;				                  //PSC预分频器的值
	TIM_TimeBaseInit(TIM2,&InitPor_TIM);							        
	
	     TIM_ClearFlag(TIM2,TIM_FLAG_Update);                			//避免刚初始化完就进入中断
	
	
   TIM_ICInitTypeDef TIM_IC_Init;
	TIM_IC_Init.TIM_Channel=TIM_Channel_1;                      //设置在通道一上面
	TIM_IC_Init.TIM_ICFilter=0x00;                              //设置输入滤波器(这里不配置滤波)
	TIM_IC_Init.TIM_ICPolarity=TIM_ICPolarity_Rising;           //设置上降沿捕获
	TIM_IC_Init.TIM_ICPrescaler=TIM_ICPSC_DIV1;                 //设置输入分频(不分频)
	TIM_IC_Init.TIM_ICSelection=TIM_ICSelection_DirectTI;       //这里选择直接映射在TI1上/IndirectTI是间接映射
	TIM_ICInit(TIM2,&TIM_IC_Init);

	TIM_Cmd(TIM2,ENABLE);                   					        //使能TIM2的功能
}


void TIM_IN_RES(){                                    //这个函数先将引脚输出低电平并延时了5ms(放电中),放电完成后标志位和计数器值分别清零.然后在把引脚切换成浮空输入模式(开始充电)
	GPIO_InitTypeDef GPIOLED_Init;
	GPIOLED_Init.GPIO_Mode=GPIO_Mode_Out_PP;
	GPIOLED_Init.GPIO_Pin=GPIO_Pin_0;
	GPIOLED_Init.GPIO_Speed=GPIO_Speed_50MHz;
	GPIO_Init(GPIOA,&GPIOLED_Init);	
	
	GPIO_ResetBits(GPIOA,GPIO_Pin_0);
	Delay_ms(5);
	TIM_ClearFlag(TIM2,TIM_FLAG_Update|TIM_FLAG_CC1);             //清除标志位
	                                       //计数器值清零
	
	GPIOLED_Init.GPIO_Mode=GPIO_Mode_IN_FLOATING;
	GPIO_Init(GPIOA,&GPIOLED_Init);
	
}

u16 TIM_IN_GET(){
	TIM_IN_RES();
	while(TIM_GetFlagStatus(TIM2,TIM_FLAG_CC1==0)){                //判断是否发生捕获中断(发生返回1,没发生返回0)
		if(TIM_GetCounter(TIM2)>Touch_Val_MAX-500){                      //这里其实是利用计数器自加的功能来做一个延时判断
			return TIM_GetCounter(TIM2);
		}
	}
	return TIM_GetCapture1(TIM2);                                  //成功发生捕获将计数器的值返回
}


u8 TIM_Key_Init(void){
	u8 i;
	u8 j;
	u16 buf[10];
	u16 temp;
	TIM2_Init2();

//连续充放电,去最大值和最小值,最后在取平均值	
	for(i=0;i<10;i++){
		buf[i]=TIM_IN_GET();
		Delay_ms(10);
	}
	for(i=0;i<9;i++){
		for(j=i+1;j<10;j++){
			if(buf[i]>buf[j]){
				temp=buf[i];
				buf[i]=buf[j];
				buf[j]=temp;
			}
		}
	}
	temp=0;
	for(i=2;i<8;i++){
		temp+=buf[i];
	}
	touch_val=temp/6;	
	
	OLED_ShowNum(1,1,touch_val,6);	//打印出 touch_val变量
	if(touch_val>Touch_Val_MAX/2){
		return 1;
	}
	else{return 0;}
}

u16 Touch_Get_MAXVal(u8 n){
	u16 temp;
	u16 res;
	while(n--){
		temp=TIM_IN_GET();
		if(temp>res){res=temp;}
	}
	return res;
}

//mode=0,单次扫描
//mode=1,连续扫描
u8 Touch_Scanf(u8 mode){
	u8 res;
	u8 sample=3;
	u16 rval;
	static u8 Keyen=0;
	if(mode){
		sample=6;
		Keyen=0;
	}
	rval=Touch_Get_MAXVal(sample);
	if(rval>(touch_val+100)&&rval<(touch_val*10)){
		if((Keyen==0)&&rval>(touch_val+100)){
			res=1;
		}
	}
	OLED_ShowNum(2,2,rval,6);  //打印rval变量
	Keyen=3;
	if(Keyen){Keyen--;}
	return res;
}
