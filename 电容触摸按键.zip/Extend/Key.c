#include "stm32f10x.h"                  // Device header
#include "Key.h"
#include "Delay.h"

#define KeyFirst GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_0)
#define KeySecond GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_1)

/**
  * @brief  按键引脚的初始化配置
  * @param  无
  * @retval 无
  */
void Key_Init(void){
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB,ENABLE);
	
	GPIO_InitTypeDef GPIO_Key;
	GPIO_Key.GPIO_Mode=GPIO_Mode_IPU;
	GPIO_Key.GPIO_Pin=GPIO_Pin_0|GPIO_Pin_1;
	GPIO_Key.GPIO_Speed=GPIO_Speed_50MHz;
	GPIO_Init(GPIOB,&GPIO_Key);
}

/**
  * @brief  判断按键是否按下
  * @param  无
  * @retval Key @判断按键是否按下(按下为1,没按下为0)
  */
int KeyOnce(void){
	int Key;
	if(KeyFirst==0){
		Delay_ms(10);
		if(KeyFirst==0){
			Key=1;
		}
	}
	else{Key=0;}
	return Key;
}

/**
  * @brief  判断按键是否按下(自锁状态)
  * @param  无
  * @retval Keep @判断按键是否按下(按下则状态取反)
  */
int KeyKeep(void){
	static int Keep=0;
	
	if(KeySecond==0){
	Delay_ms(10);
	if(KeySecond==0){
	if(Keep==1){
		Keep=0;
	}
	else{Keep=1;}
}
}
	return Keep;
}
