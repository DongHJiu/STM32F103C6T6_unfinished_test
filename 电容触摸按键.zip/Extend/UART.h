#ifndef __USAR_H
#define __USAR_H


void UART_Init(void);
//void NVIC_USART1(void);

#endif
