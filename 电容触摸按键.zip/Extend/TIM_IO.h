#ifndef __TIM_IO_H
#define __TIM_IO_H

void TIM2_Init2(void);
u8 TIM_Key_Init(void);
u8 Touch_Scanf(u8 mode);
extern u16 touch_val;

#endif
