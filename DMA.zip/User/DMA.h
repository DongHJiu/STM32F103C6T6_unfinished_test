#ifndef __DMA_H
#define __DMA_H

void DMA_Conifg(DMA_Channel_TypeDef*DMA_CHx,u32 cpar,u32 cmar,u16 cnder);
void DMA_Enable(DMA_Channel_TypeDef*DMA_CHx);


#endif
