#include "stm32f10x.h"                  // Device header
#include "Delay.h"
#include "DMA.h"
#include "UART.h"

u32 CharData=1234;

int main(void){
	UART_Init();
	DMA_Conifg(DMA1_Channel4,(u32)&USART1->DR,CharData,200);
	while(1){
		DMA_Enable(DMA1_Channel4);
		Delay_ms(2000);
	}
}
