#include "stm32f10x.h"                  // Device header

u16 DMATly;


void DMA_Conifg(DMA_Channel_TypeDef*DMA_CHx,u32 cpar,u32 cmar,u16 cnder){      //配置DMA1_CHx

	RCC_AHBPeriphClockCmd(RCC_AHBPeriph_DMA1,ENABLE);
	
	DMA_DeInit(DMA_CHx);
	DMATly=cnder; 
	DMA_InitTypeDef DMA_NEW; 
	
	DMA_NEW.DMA_BufferSize=cnder;                                    //传输的数据量(这里配置的数据量只会执行一次,执行完后便会清零)
	DMA_NEW.DMA_DIR=DMA_DIR_PeripheralDST;                           //传输的方向(从存储器到外设)
	DMA_NEW.DMA_M2M=DMA_M2M_Disable;                                 //是否设置为存储器到存储器(不设置)
	DMA_NEW.DMA_MemoryBaseAddr=cmar;                                 //存储器的基地址
	DMA_NEW.DMA_MemoryDataSize=DMA_MemoryDataSize_Byte;              //存储器传输数据的长度
	DMA_NEW.DMA_MemoryInc=DMA_MemoryInc_Enable;                      //存储器是否增量(开启)
	DMA_NEW.DMA_Mode=DMA_Mode_Normal;                                //选择是否循环执行(这里不循环)
	DMA_NEW.DMA_PeripheralBaseAddr=cpar;                             //外设的基地址
	DMA_NEW.DMA_PeripheralDataSize=DMA_PeripheralDataSize_Byte;      //外设传输数据的长度
	DMA_NEW.DMA_PeripheralInc=DMA_PeripheralInc_Disable;             //外设是否增量(不开启)
	DMA_NEW.DMA_Priority=DMA_Priority_Medium;                        //设置优先级(这里设置中等)
	
	DMA_Init(DMA_CHx,&DMA_NEW);
	
}

 
void DMA_Enable(DMA_Channel_TypeDef*DMA_CHx){                      //使能DMA1_CHx
 
	USART_DMACmd(USART1,USART_DMAReq_Tx,ENABLE);                     //开启USART1_TX的DMA发送
	DMA_Cmd(DMA_CHx,DISABLE);                                        //先关闭使能在传输数据量
	DMA_SetCurrDataCounter(DMA_CHx,DMATly);                          //开始传输DMATly个数据
	DMA_Cmd(DMA_CHx,ENABLE);
	//DMA_GetFlagStatus(DMA1_FLAG_GL4);                              //判断DMA1通道4是否传输完成(没有完成返回RESET)
	//DMA_ClearFlag(DMA1_FLAG_GL4);                                  //清除DMA1通道4传输完成标志位
	//DMA_GetCurrDataCounter(DMA1_Channel4);                         //返回当前DMA1通道4剩余的数据
}
