#ifndef __DAC_H
#define __DAC_H

void DACtheInit(void);
void DAC1_Set(u16 NEW);


#endif