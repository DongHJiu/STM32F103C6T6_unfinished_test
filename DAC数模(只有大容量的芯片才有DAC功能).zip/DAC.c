#include "stm32f10x.h"                  // Device header


void DACtheInit(void){

	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA,ENABLE);
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_DAC,ENABLE);
	
	GPIO_InitTypeDef GPIOAF_Init;
	GPIOAF_Init.GPIO_Mode=GPIO_Mode_AIN;                                      //设置管脚为模拟输入
	GPIOAF_Init.GPIO_Pin=GPIO_Pin_4;
	GPIOAF_Init.GPIO_Speed=GPIO_Speed_50MHz;
	GPIO_Init(GPIOA,&GPIOAF_Init);
	GPIO_SetBits(GPIOA,GPIO_Pin_4);
	
	DAC_InitTypeDef DACAF_Init;
	DACAF_Init.DAC_LFSRUnmask_TriangleAmplitude=DAC_LFSRUnmask_Bit0;          //屏蔽，幅值设置(方形波和噪声波生成使用的)
	DACAF_Init.DAC_OutputBuffer=DAC_OutputBuffer_Disable;                     //DAC1输出缓存关闭，BOFF1=1
	DACAF_Init.DAC_Trigger=DAC_Trigger_None;                                  //不使用触发功能，TEN1=0
	DACAF_Init.DAC_WaveGeneration=DAC_WaveGeneration_None;                    //不使用波形发生
	DAC_Init(DAC_Channel_1,&DACAF_Init);
	
	DAC_Cmd(DAC_Channel_1,ENABLE);           //使能DAC1
	
	DAC_SetChannel1Data(DAC_Align_12b_R,0);                   //设置DAC值为12位右对齐数据格式(这里已经使输出了0V的电压了)
}


/**
*设置通道1输出电压
*NEW：0~3300==0~3.3V
**/
void DAC1_Set(u16 NEW){

	float tema;
	tema=NEW;
	tema=tema/1000;
	tema=tema*(4096/3.3);   //这是个公式
	DAC_SetChannel1Data(DAC_Align_12b_R,tema);      //配合其他函数可以控制输出电压的高低

}


